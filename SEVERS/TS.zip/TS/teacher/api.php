<?php
/**
 * Created by PhpStorm.
 * User: GIANGND-SVMC
 * Date: 09/04/2016
 * Time: 10:45 SA
 */
$response = array();
require_once __DIR__ . '/db_connect.php';
$db = new DB_CONNECT();
if (isset($_GET['loginteacher']) && isset($_GET['user']) && isset($_GET['pass'])) {
    $user = $_GET['user'];
    $pass = $_GET['pass'];
    $result = mysql_query("SELECT * FROM tblteacher where username = '$user' and password = '$pass'") or die(mysql_error());
    if (mysql_num_rows($result) > 0) {
        $result = mysql_fetch_array($result);
        $response["success"] = 1;
        $response["teacher"] = array();
        $data = array();
        $data['idteacher'] = $result['idteacher'];
        $data['name'] = $result['name'];
        $data['phone'] = $result['phone'];
        $data['email'] = $result['email'];
        $data['address'] = $result['address'];
        $data['images'] = $result['images'];
        array_push($response["teacher"], $data);
        echo json_encode($response);
    } else {
        $response["success"] = 0;
        echo json_encode($response);
    }
    exit;
}
if (isset($_GET['loginstudent']) && isset($_GET['code']) && isset($_GET['pass'])) {
    $user = $_GET['code'];
    $pass = $_GET['pass'];
    $result = mysql_query("SELECT * FROM tblstudent where code = '$user' and password = '$pass'") or die(mysql_error());
    if (mysql_num_rows($result) > 0) {
        $response["success"] = 1;
        $response['message'] = "login success";
        echo json_encode($response);
    } else {
        $response["success"] = 0;
        $response["message"] = "login false";
        echo json_encode($response);
    }
    exit;
}
if (isset($_GET['getallteacher'])) {
    $result = mysql_query("SELECT * FROM tblteacher order by name desc") or die(mysql_error());
    if (!empty($result)) {
        if (mysql_num_rows($result) > 0) {
            $response["teachers"] = array();
            while ($row = mysql_fetch_array($result)) {
                $teacher = array();
                $teacher["name"] = $row["name"];
                $teacher["phone"] = $row["phone"];
                $teacher["email"] = $row["email"];
                $teacher["address"] = $row["address"];
                $teacher["images"] = $row["images"];
                array_push($response["teachers"], $teacher);
            }
            $response["success"] = 1;
            echo json_encode($response);
        } else {
            $response["success"] = 0;
            $response["message"] = "No teacher found";
            echo json_encode($response);
        }
    } else {
        $response["success"] = 0;
        $response["message"] = "No teacher found";
        echo json_encode($response);
    }
    exit;
}
if (isset($_GET['getdetailstudent']) && isset($_GET['code'])) {
    $code = $_GET['code'];
    // mysql inserting a new row
    $result = mysql_query("SELECT s.*,c.name as class FROM tblstudent as s left join tblclass as c on s.idClass = c.idClass where code = '$code'") or die('errror');

    if (!empty($result)) {
        // check for empty result
        if (mysql_num_rows($result) > 0) {

            $result = mysql_fetch_array($result);

            $student = array();
            $student["code"] = $code;
            $student["name"] = $result["name"];
            $student["birthday"] = $result["birthday"];
            $student["address"] = $result["address"];
            $student["phone"] = $result["phone"];
            $student["class"] = $result["class"];
            $student["description"] = $result["description"];
            $student["avatar"] = $result["avatar"];
            // success
            $response["success"] = 1;

            // user node
            $response["student"] = array();

            array_push($response["student"], $student);

            // echoing JSON response
            echo json_encode($response);
        }
    }
}
if (isset($_GET['getallclass']) && isset($_GET['idteacher'])) {
    $idteacher = $_GET['idteacher'];
    $result = mysql_query("select distinct c.* from tblclass as c left join tblschedule as s on c.idclass = s.idclass left join tblteacher as t on t.idteacher = s.idteacher where t.idteacher = '$idteacher';") or die(mysql_error());

    if (!empty($result)) {
        // check for empty result
        if (mysql_num_rows($result) > 0) {
            // looping through all results
            // audios node
            $response["classes"] = array();
            while ($row = mysql_fetch_array($result)) {
                // temp user array
                $class = array();
                $class["idclass"] = $row["idclass"];
                $class["name"] = $row["name"];
                $class["description"] = $row["description"];
                // push single product into final response array
                array_push($response["classes"], $class);
            }
            // success
            $response["success"] = 1;

            // echoing JSON response
            echo json_encode($response);
        } else {
            // no audios found
            $response["success"] = 0;
            $response["message"] = "No teacher found";
            // echo no audios JSON
            echo json_encode($response);
        }
    }
    exit;
}
//get ds mon hoc ma giao vien day o lop nao do
if (isset($_GET['getdetailclass']) && isset($_GET['idteacher']) && isset($_GET['idclass'])) {
    $idteacher = $_GET['idteacher'];
    $idclass = $_GET['idclass'];
    $result = mysql_query("SELECT su.* FROM tblsubject as su left join tblschedule as s on su.idsubject = s.idsubject where s.idclass = $idclass and s.idteacher = $idteacher;") or die(mysql_error());
    if (!empty($result)) {
        if (mysql_num_rows($result) > 0) {
            $response["subject"] = array();
            while ($row = mysql_fetch_array($result)) {
                $subject = array();
                $subject["idsubject"] = $row["idsubject"];
                $subject["name"] = $row["name"];
                $subject["description"] = $row["description"];
                array_push($response["subject"], $subject);
            }
            $response["success"] = 1;
            echo json_encode($response);
        } else {
            $response["success"] = 0;
            $response["message"] = "No class found";
            echo json_encode($response);
        }
    } else {
        $response["success"] = 0;
        $response["message"] = "No class found";
        echo json_encode($response);
    }
    exit;
}
if (isset($_GET['getallstudentinclass']) && isset($_GET['idclass'])) {
    $idclass = $_GET['idclass'];
    $result = mysql_query("select s.* from tblstudent as s left join tblclass as c on c.idclass = s.idclass where c.idclass = '$idclass';") or die(mysql_error());
    if (!empty($result)) {

        if (mysql_num_rows($result) > 0) {

            $response["students"] = array();
            while ($row = mysql_fetch_array($result)) {
                $students = array();
                $students["idstudent"] = $row["idstudent"];
                $students["name"] = $row["name"];
                $students["code"] = $row["code"];
                $students["birthday"] = $row["birthday"];
                $students["address"] = $row["address"];
                $students["phone"] = $row["phone"];
                $students["description"] = $row["phone"];
                $students["avatar"] = $row["avatar"];
                array_push($response["students"], $students);
            }
            $response["success"] = 1;
            echo json_encode($response);
        } else {
            $response["success"] = 0;
            $response["message"] = "No student in class";
            echo json_encode($response);
        }
    } else {
        $response["success"] = 0;
        $response["message"] = "No student in class";
        echo json_encode($response);
    }
    exit;
}
if (isset($_GET['attendance']) && isset($_GET['idstudent']) && isset($_GET['idschedule'])) {
    $idstudent = $_GET['idstudent'];
    $idschedule = $_GET['idschedule'];

    $result = mysql_query("INSERT INTO tblattendence (idschedule, idstudent, isattendence) VALUES($idschedule, $idstudent, '1')");

    if ($result) {
        $response["success"] = 1;
        $response["message"] = "attendence success";
        echo json_encode($response);
    } else {
        $response["success"] = 0;
        $response["message"] = "attendence false";
        echo json_encode($response);
    }
    exit;
}
if (isset($_GET['editinforstudent']) && isset($_GET['code']) && isset($_GET['birthday']) && isset($_GET['address']) && isset($_GET['phone']) && isset($_GET['description'])) {
    $code = $_GET['code'];
    $birthday = $_GET['birthday'];
    $address = $_GET['address'];
    $phone = $_GET['phone'];
    $description = $_GET['description'];
    $result = mysql_query("UPDATE tblstudent SET birthday = '$birthday', address = '$address', phone = '$phone', description = '$description' WHERE code = '$code'") or die('giang');
    if ($result) {
        $response["success"] = 1;
        $response["message"] = "Update success.";
        echo json_encode($response);
    } else {
        $response["success"] = 0;
        $response["message"] = "Update false.";

    }
    exit;
}
if (isset($_GET['getdetailteacher']) && isset($_GET['name'])) {
    $name = $_GET['name'];
    $result = mysql_query("SELECT * FROM tblteacher as t  where t.name LIKE '%$name%' order by t.name desc;") or die(mysql_error());
    if (!empty($result)) {
        if (mysql_num_rows($result) > 0) {
            $response["teachers"] = array();
            while ($row = mysql_fetch_array($result)) {
                $teacher = array();
                $teacher["name"] = $row["name"];
                $teacher["phone"] = $row["phone"];
                $teacher["email"] = $row["email"];
                $teacher["address"] = $row["address"];
                $teacher["images"] = $row["images"];
                array_push($response["teachers"], $teacher);
            }
            $response["success"] = 1;

            echo json_encode($response);
        } else {
            $response["success"] = 0;
            $response["message"] = "No teacher found";
            echo json_encode($response);
        }
    } else {
        $response["success"] = 0;
        $response["message"] = "No teacher found";
        echo json_encode($response);
    }
    exit;
}
if (isset($_GET['createlistattendance']) && isset($_GET['idclass']) && isset($_GET['idteacher']) && isset($_GET['idsubject']) && isset($_GET['idtiethoc'])) {

    $idclass = $_GET['idclass'];
    $idteacher = $_GET['idteacher'];
    $idsubject = $_GET['idsubject'];
    $idtiethoc = $_GET['idtiethoc'];
    $t = time();
    $time = date("Y-m-d", $t);
    $result1 = mysql_query("select s.* from tblschedule as s where idclass = '$idclass' and idtiethoc = '$idtiethoc' and idtiethoc = '$idtiethoc' and idteacher = '$idteacher' ;") or die('errror');
    //select id schedule
    if (!empty($result1)) {
        if (mysql_num_rows($result1) > 0) {

            $result1 = mysql_fetch_array($result1);

            $idschedule = (int)$result1["idschedule"];
            //get tat ca sinh vien trong lop
            $result1 = mysql_query("select s.* from tblstudent as s left join tblclass as c on c.idclass = s.idclass where c.idclass = '$idclass';") or die(mysql_error());
            if (!empty($result1)) {

                if (mysql_num_rows($result1) > 0) {

                    $response1["students"] = array();
                    while ($row = mysql_fetch_array($result1)) {
                        $student = array();
                        $student["idstudent"] = $row["idstudent"];
                        array_push($response1["students"], $student);
                    }
                    $t = time();
                    $astime = date("Y-m-d", $t);
                    //insert ban ghi diem danh
                    foreach ($response1["students"] as $value) {
                        $id_student = $value['idstudent'];
                        $result = mysql_query("INSERT INTO tblattendence (idschedule, idstudent, isattendence,astime) VALUES($idschedule, $id_student, 2,'$astime');") or die(mysql_error());
                    }

                    // sau khi insert thanh cong danh sach sinh vien vao danh sach diem danh
                    // show ra
                    //show ra danh sach diem danh
                    $result = mysql_query("select * from tblattendence as a left join tblstudent as s on a.idstudent = s.idstudent where a.astime = '$time';");

                    if (!empty($result)) {
                        // check for empty result
                        if (mysql_num_rows($result) > 0) {
                            // looping through all results
                            // audios node
                            $response["attendences"] = array();
                            while ($row = mysql_fetch_array($result)) {
                                // temp user array
                                $attendences = array();
                                $attendences["idstudent"] = $row["idstudent"];
                                $attendences["name"] = $row["name"];
                                $attendences["isattendence"] = $row["isattendence"];
                                $attendences["idattendence"] = $row["idattendence"];
                                $attendences["avatar"] = $row["avatar"];
                                $attendences["code"] = $row["code"];
                                array_push($response["attendences"], $attendences);
                            }
                            $response["success"] = 1;
                            echo json_encode($response);
                        } else {
                            $response["success"] = 0;
                            $response["message"] = "error";
                            echo json_encode($response);
                        }
                    }
                } else {
                    $response["success"] = 0;
                    $response["message"] = "No teacher found";
                    echo json_encode($response);
                }
            }
        }
    } else {
        $response["success"] = 0;
        $response["message"] = "No teacher found";
        echo json_encode($response);
    }
    exit;
}
if (isset($_GET['updateattendance']) && isset($_GET['idattendence']) && isset($_GET['isattendence'])) {
    $idattendence = $_GET['idattendence'];
    $isattendence = $_GET['isattendence'];
    $result = mysql_query("UPDATE tblattendence SET isattendence = '$isattendence' WHERE idattendence = '$idattendence'") or die('giang');
    if ($result) {
        $response["success"] = 1;
        $response["message"] = "Update success.";
        echo json_encode($response);
    } else {
        $response["success"] = 0;
        $response["message"] = "Update false.";
    }
    exit;
}
if (isset($_GET['getlistattendence']) && isset($_GET['idclass']) && isset($_GET['isattendence'])) {
    $idattendence = $_GET['idattendence'];
    $isattendence = $_GET['isattendence'];
    $result = mysql_query("UPDATE tblattendence SET isattendence = '$isattendence' WHERE idattendence = '$idattendence'") or die('giang');
    if ($result) {
        $response["success"] = 1;
        $response["message"] = "Update success.";
        echo json_encode($response);
    } else {
        $response["success"] = 0;
        $response["message"] = "Update false.";
    }
    exit;
}
// no audios found
$response["success"] = 0;
$response["message"] = "request false";
// echo no audios JSON
echo json_encode($response);
?>