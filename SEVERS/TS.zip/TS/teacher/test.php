<?php
/**
 * Created by PhpStorm.
 * User: GIANGND-SVMC
 * Date: 09/04/2016
 * Time: 4:35 CH
 */
//$t = time();
//$time = date("Y-m-d H:i:s", $t);
//var_dump($time);
//echo rand();
$url = "https://faceppadapter.herokuapp.com/application/recognize";
$param = "http://pizzaviet.vn/smac/edtech/images/1497561224.png";
$data = array('link' => "$param");

// use key 'http' even if you send the request to https://...
$options = array(
    'http' => array(
        'header' => "Content-type: application/x-www-form-urlencoded\r\n",
        'method' => 'POST',
        'content' => http_build_query($data)
    )
);
$context = stream_context_create($options);
$result = file_get_contents($url, false, $context);
echo $result;