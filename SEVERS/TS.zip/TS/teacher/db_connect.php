<?php

class DB_CONNECT
{
    function __construct()
    {
        $this->connect();
    }

    function __destruct()
    {
        $this->close();
    }

    function connect()
    {
        require_once __DIR__ . '/db_config.php'; //tạo 1 kết nối đến máy chủ qua config OK!
        $con = mysql_connect(DB_SERVER, DB_USER, DB_PASSWORD) or die(mysql_error());
        mysql_query("SET NAMES 'utf8'", $con);
        mysql_select_db(DB_DATABASE, $con) or die(mysql_error()) or die(mysql_error());

        return $con;
    }

    function close()
    {
        mysql_close();
    }
}

?>