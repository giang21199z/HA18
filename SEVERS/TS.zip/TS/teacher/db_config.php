<?php
define('DB_USER', "root"); 
define('DB_PASSWORD', ""); 
define('DB_DATABASE', "ts");
define('DB_SERVER', "localhost");
?>