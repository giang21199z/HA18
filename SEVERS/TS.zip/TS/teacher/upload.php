<?php
/**
 * Created by PhpStorm.
 * User: GIANGND-SVMC
 * Date: 10/04/2016
 * Time: 11:38 SA
 */
if(isset($_POST['image'])){
    $image = $_POST['image'];
    $namefile = rand();
    $path = "images/$namefile.png";
    file_put_contents($path,base64_decode($image));
    // tao xong file
    $url = "https://faceppadapter.herokuapp.com/application/recognize";
    $param = "http://pizzaviet.vn/smac/edtech/$path";
    $data = array('link' => "$param");

    // use key 'http' even if you send the request to https://...
    $options = array(
        'http' => array(
            'header' => "Content-type: application/x-www-form-urlencoded\r\n",
            'method' => 'POST',
            'content' => http_build_query($data)
        )
    );
    $context = stream_context_create($options);
    $result = file_get_contents($url, false, $context);
    echo $result;
    exit;
}
echo "eror";
