<?php
if(isset($_POST['image'])){
    $image = $_POST['image'];
    $namefile = rand();
    $path = "images/$namefile.png";
    file_put_contents($path,base64_decode($image));
    $url = "https://faceppadapter.herokuapp.com/application/recognize";
    $link = "http://pizzaviet.vn/smac/edtech/giangnd/test.jpg";
    echo "success";
    exit;
}
echo "eror";

