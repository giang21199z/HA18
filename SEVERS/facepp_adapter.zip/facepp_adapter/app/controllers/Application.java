package controllers;

import com.facepp.error.FaceppParseException;
import com.facepp.http.HttpRequests;
import com.facepp.http.PostParameters;
import com.facepp.result.FaceppResult;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import play.*;
import play.mvc.*;

import java.util.*;

import models.*;

public class Application extends Controller {

    public static final String API_KEY = "d147b2e375ad04ca5c728449645389b8";
    public static final String API_SECRET = "PbGu3S7VVs6iLg6CU5xCyGDnVGud0rTk";

    public static void index() {
        render();
    }

    public static void addPerson() {
        System.out.println("add person");
        String id = params.get("id");
        System.out.println(id);

        HttpRequests httpRequests = new HttpRequests(API_KEY, API_SECRET);
        Object response[] = new Object[2];
        try {
            System.out.println(httpRequests.groupCreate(new PostParameters().setGroupName("edtech")));
//            System.out.println(httpRequests.personCreate(new PostParameters().setPersonName(id)));
//            System.out.println(httpRequests.groupAddPerson(new PostParameters().setGroupName("edtech").setPersonName(id)));
            response[0] = "success";
        } catch (FaceppParseException e) {
            response[0] = "fail";
            response[1] = e.getMessage();
            e.printStackTrace();
        } finally {
            renderJSON(response);
        }
    }

    public static void addFace() {
        System.out.println("add face");
        String id = params.get("id");
        String link = params.get("link");
        System.out.println(id + " | " + link);

        HttpRequests httpRequests = new HttpRequests(API_KEY, API_SECRET);
        FaceppResult result = null;
        Object response[] = new Object[2];
        try {
            result = httpRequests.detectionDetect(new PostParameters().setUrl(link));
            for (int i = 0; i < result.get("face").getCount(); ++i) {
                System.out.println(httpRequests.personAddFace(new PostParameters()
                        .setPersonName(id).setFaceId(result.get("face").get(i).get("face_id").toString())));
            }
            response[0] = "success";
        } catch (FaceppParseException e) {
            response[0] = "fail";
            response[1] = e.getMessage();
            e.printStackTrace();
        } finally {
            renderJSON(response);
        }
    }

    public static void retrain() {
        System.out.println("retrain");
        HttpRequests httpRequests = new HttpRequests(API_KEY, API_SECRET);
        Object response[] = new Object[2];
        try {
            System.out.println(httpRequests.train(new PostParameters().setGroupName("edtech").setType("all")));
            response[0] = "success";
        } catch (FaceppParseException e) {
            response[0] = "fail";
            response[1] = e.getMessage();
            e.printStackTrace();
        } finally {
            renderJSON(response);
        }
    }

    public static void recognize() {
        System.out.println("recognize");
        HttpRequests httpRequests = new HttpRequests(API_KEY, API_SECRET);
        FaceppResult result = null;
        String link = params.get("link");
        System.out.println(link);
        Object response[] = new Object[2];
        ArrayList<String> ids = new ArrayList<String>();
        try {
            result = httpRequests.detectionDetect(new PostParameters().setUrl(link));

            for (int i = 0; i < result.get("face").getCount(); ++i) {
                FaceppResult recognizeResult = httpRequests.request("recognition", "identify", new PostParameters()
                        .setGroupName("edtech")
                        .setKeyFaceId(result.get("face").get(i).get("face_id").toString()));
                JsonObject object = (JsonObject) new JsonParser().parse(recognizeResult.toString());
                JsonArray candidates = object.get("face").getAsJsonArray().get(0).getAsJsonObject().get("candidate").getAsJsonArray();
                if (candidates.size() > 0 && candidates.get(0).getAsJsonObject().get("confidence").getAsDouble() >= 41) {
                    ids.add(candidates.get(0).getAsJsonObject().get("person_name").getAsString());
                } else {
                    ids.add("null");
                }
            }
            response[0] = "success";
            response[1] = ids;
        } catch (FaceppParseException e) {
            response[0] = "fail";
            response[1] = e.getMessage();
            e.printStackTrace();
        } finally {
            renderJSON(response);
        }
    }

}