/**
 * Created by Ken on 09/04/2016.
 */
var app = angular.module('myApp', ['ngMaterial']);

app.controller('myCtrl', function ($scope, $http) {

    $scope.data = {};
    $scope.data.links = [];

    $scope.addPerson = function () {
        if ($scope.id == null || $scope.id === '') {
            alert('Enter id');
            return;
        }
        console.log($scope.id);
        var req = {
            method: 'POST',
            url: '/application/addPerson',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
            },
            params: {
                id: $scope.id
            }
        };

        $http(req).then(function (response) {
            $scope.result = response.data;
            console.log($scope.result[0]);
            if ($scope.result[0] === "success") {
                alert('success');
            } else {
                alert("FAIL:" + $scope.result[1]);
            }
        }, function (response) {
            console.log('fail');
            console.log(response);
        });
    }

    $scope.addFace = function () {
        if ($scope.id == null || $scope.id === '') {
            alert('Enter id');
            return;
        }
        if ($scope.faceLink == null || $scope.faceLink === '') {
            alert('Enter face link');
            return;
        }
        console.log($scope.id);
        console.log($scope.faceLink);
        var req = {
            method: 'POST',
            url: '/application/addFace',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
            },
            params: {
                id: $scope.id,
                link: $scope.faceLink
            }
        };

        $http(req).then(function (response) {
            $scope.result = response.data;
            console.log($scope.result);
            if ($scope.result[0] === "success") {
                alert('success');
            } else {
                alert("FAIL:" + $scope.result[1]);
            }
        }, function (response) {
            console.log('fail');
            console.log(response);
        });
    }

    $scope.retrain = function () {
        var req = {
            method: 'POST',
            url: '/application/retrain',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
            }
        };

        $http(req).then(function (response) {
            $scope.result = response.data;
            console.log($scope.result[0]);
            if ($scope.result[0] === "success") {
                alert('success');
            } else {
                alert("FAIL:" + $scope.result[1]);
            }
        }, function (response) {
            console.log('fail');
            console.log(response);
        });
    }

    $scope.recognize = function () {
        if ($scope.recognizeLink == null || $scope.recognizeLink === '') {
            alert('Enter link');
            return;
        }
        console.log($scope.recognizeLink);
        var req = {
            method: 'POST',
            url: '/application/recognize',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
            },
            params: {
                link: $scope.recognizeLink
            }
        };

        $http(req).then(function (response) {
            $scope.result = response.data;
            console.log($scope.result[0]);
            if ($scope.result[0] === "success") {
                alert('success');
                console.log($scope.result);
                console.log($scope.result.toString());
            } else {
                alert("FAIL:" + $scope.result[1]);
            }
        }, function (response) {
            console.log('fail');
            console.log(response);
        });
    }
});